# XMPP项目
XMPP项目代码

## 安装说明
1. pod isntall
2. 服务器端安装openfire
3. XMPPConfig文件中IP地址改为服务器地址
4. XMPPConfig文件中域改为服务器openfire域

## 功能
* [x] 登陆注册
* [x] 发送消息
* [x] 接收消息
* [x] 接收好友请求
* [x] 发起好友请求
* [x] 图片消息
* [ ] 语音消息
* [ ] 地理位置消息
