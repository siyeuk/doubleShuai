//
//  AddFriendViewController.h
//  0834XMPP
//
//  Created by 郑建文 on 15/11/25.
//  Copyright © 2015年 Lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFriendViewController : UIViewController

@end
