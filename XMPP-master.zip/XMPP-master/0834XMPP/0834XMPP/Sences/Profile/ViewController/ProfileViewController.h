//
//  ProfileViewController.h
//  0834XMPP
//
//  Created by 郑建文 on 16/8/30.
//  Copyright © 2016年 Lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileViewController : UIViewController

@end
