//
//  PageTransition.h
//  WXSTransition
//
//  Created by 王小树 on 16/5/30.
//  Copyright © 2016年 王小树. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PageTransition : UIViewController

@end
