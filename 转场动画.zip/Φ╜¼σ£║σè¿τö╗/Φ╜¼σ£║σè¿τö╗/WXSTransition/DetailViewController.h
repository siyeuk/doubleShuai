//
//  DetailViewController.h
//  WXSTransition
//
//  Created by 王小树 on 16/5/31.
//  Copyright © 2016年 王小树. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+WXSTransition.h"
@interface DetailViewController : UIViewController

@end
