//
//  main.m
//  CATransition
//
//  Created by 李泽鲁 on 14/12/12.
//  Copyright (c) 2014年 李泽鲁. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
