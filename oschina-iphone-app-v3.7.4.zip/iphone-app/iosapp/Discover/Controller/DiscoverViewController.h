//
//  DiscoverViewController.h
//  iosapp
//
//  Created by AeternChan on 7/16/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscoverViewController : UITableViewController

- (void)dawnAndNightMode;

@end
