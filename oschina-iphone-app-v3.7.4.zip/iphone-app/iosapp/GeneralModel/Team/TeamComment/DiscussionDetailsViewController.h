//
//  DiscussionDetailsViewController.h
//  iosapp
//
//  Created by chenhaoxiang on 4/24/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import "TeamRepliesBVC.h"

@interface DiscussionDetailsViewController : TeamRepliesBVC

- (instancetype)initWithDiscussionID:(int)discussionID;

@end
