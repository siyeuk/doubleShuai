//
//  TeamCenter.h
//  iosapp
//
//  Created by AeternChan on 4/27/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import "SwipableViewController.h"

@interface TeamCenter : SwipableViewController

@end
