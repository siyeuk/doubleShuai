//
//  TeamMemberListViewController.h
//  iosapp
//
//  Created by AeternChan on 6/2/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import "OSCObjsViewController.h"

@interface TeamMemberListViewController : OSCObjsViewController

@end
