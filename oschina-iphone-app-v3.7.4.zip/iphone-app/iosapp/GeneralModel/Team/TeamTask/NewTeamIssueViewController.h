//
//  NewTeamIssueViewController.h
//  iosapp
//
//  Created by Holden on 15/5/21.
//  Copyright (c) 2015年 oschina. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewTeamIssueViewController : UITableViewController


@end
