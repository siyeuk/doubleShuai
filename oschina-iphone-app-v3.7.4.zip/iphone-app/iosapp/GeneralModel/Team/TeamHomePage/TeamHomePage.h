//
//  TeamHomePage.h
//  iosapp
//
//  Created by chenhaoxiang on 4/16/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeamHomePage : UITableViewController

- (instancetype)initWithTeamID:(int)teamID;

@end
