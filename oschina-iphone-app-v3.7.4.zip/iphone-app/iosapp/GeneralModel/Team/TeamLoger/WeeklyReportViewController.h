//
//  WeeklyReportViewController.h
//  iosapp
//
//  Created by AeternChan on 4/29/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeeklyReportViewController : UIViewController

- (instancetype)initWithTeamID:(int)teamID;

@end
