//
//  WeeklyReportDetailViewController.h
//  iosapp
//
//  Created by chenhaoxiang on 5/6/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import "TeamRepliesBVC.h"

@interface WeeklyReportDetailViewController : TeamRepliesBVC

- (instancetype)initWithReportID:(int)reportID;

@end
