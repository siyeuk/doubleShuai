//
//  OSCMsgChatController.h
//  iosapp
//
//  Created by Graphic-one on 16/8/29.
//  Copyright © 2016年 oschina. All rights reserved.
//

//可删除文件
#import "BottomBarViewController.h"

@interface OSCMsgChatController : BottomBarViewController

- (instancetype)initWithAuthorId:(NSInteger)authorId userName:(NSString* )name;

@end
