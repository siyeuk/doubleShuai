//
//  OSCAtMeController.h
//  iosapp
//
//  Created by Graphic-one on 16/8/22.
//  Copyright © 2016年 oschina. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OSCAtMeController : UIViewController

@property (nonatomic, copy) void (^didRefreshSucceed)();

@end
