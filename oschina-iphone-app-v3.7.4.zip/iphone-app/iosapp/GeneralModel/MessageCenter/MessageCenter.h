//
//  MessageCenter.h
//  iosapp
//
//  Created by chenhaoxiang on 3/1/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import "SwipableViewController.h"

@interface MessageCenter : SwipableViewController

- (instancetype)initWithNoticeCounts:(NSArray *)noticeCounts;

@end
