//
//  OSCMessageCenterController.h
//  iosapp
//
//  Created by Graphic-one on 16/8/23.
//  Copyright © 2016年 oschina. All rights reserved.
//

#import "SwipableViewController.h"

@interface OSCMessageCenterController : SwipableViewController

- (instancetype)initWithNoticeCounts:(NSArray *)noticeCounts;

@end
