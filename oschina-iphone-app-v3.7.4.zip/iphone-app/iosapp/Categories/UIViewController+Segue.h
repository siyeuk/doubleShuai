//
//  UIViewController+Segue.h
//  iosapp
//
//  Created by AeternChan on 7/16/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Segue)

- (IBAction)pushLoginViewController:(id)sender;
- (IBAction)pushSearchViewController:(id)sender;

@end
