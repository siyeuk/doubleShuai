//
//  NSTextAttachment+Util.h
//  iosapp
//
//  Created by ChanAetern on 4/10/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSTextAttachment (Util)

- (void)adjustY:(CGFloat)y;

@end
