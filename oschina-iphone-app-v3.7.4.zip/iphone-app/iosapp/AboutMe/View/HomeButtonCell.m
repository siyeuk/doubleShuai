//
//  HomeButtonCell.m
//  iosapp
//
//  Created by 李萍 on 16/7/13.
//  Copyright © 2016年 oschina. All rights reserved.
//

#import "HomeButtonCell.h"

@implementation HomeButtonCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
