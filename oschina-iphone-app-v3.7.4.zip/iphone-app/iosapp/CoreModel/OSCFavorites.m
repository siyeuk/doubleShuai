//
//  OSCFavorites.m
//  iosapp
//
//  Created by 李萍 on 16/8/29.
//  Copyright © 2016年 oschina. All rights reserved.
//

#import "OSCFavorites.h"

@implementation OSCFavorites

@end
