//
//  OSCNotice.m
//  iosapp
//
//  Created by 李萍 on 16/8/26.
//  Copyright © 2016年 oschina. All rights reserved.
//

#import "OSCNotice.h"

@implementation OSCNotice

@end
